# 1_Monitoring.py - Daily diabetes monitor UI
