# main.py - Streamlit frontend for DR prediction
